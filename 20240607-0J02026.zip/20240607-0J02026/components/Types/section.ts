type section = {
  sectionID: string
  roomID: string
  sectionName: string
  createdDate: Date
  color: string
}
