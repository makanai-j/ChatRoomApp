<script setup lang="ts">
//import Home from './components/Pages/Home.vue'
//import GateWayTest from './components/Pages/GateWayTest.vue'
import Home from './components/Pages/Home.vue'
</script>
<template>
  <router-view />
</template>

<style></style>
